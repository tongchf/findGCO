#!usr/bin/perl -w
use strict;
use Getopt::Long;

sub prtHelp{
    print "This program is used to detect gene conversion events in SNP blocks for both parents\n";
    print "\n";
    print "Usage: perl countingGCOs.pl [Options]  <input.rmdup.bam> \n";
    print "\n";
    print "Options:\n";
    print "       -f <string> the reference file\n";
    print "       -Q <int> minimum base quality\n";
    print "       -m <int> Whether two parental linkage maps are used for identifying COs (1) or not (0) [1]\n";
    print "       -n <int> minimum number of snps in output SNP blocks, better use the same as in Block_constructer[5]\n";
    print "       -a <int> minimum depth for each alleles in heterozygous genotype [3]\n";
    print "       -d1 <int> minimum depth for heterozygous genotype [6]\n";
    print "       -d2 <int> minimum depth for homozygous genotype [5]\n";
    print "\n";
}

my ($prefix,$refseqfile);
my ($bq,$m,$n,$d1,$d2,$a);

GetOptions(
      "f:s"=>\$refseqfile,
      "Q:i"=>\$bq,
      "m:i"=>\$m,
      "n:i"=>\$n,
      "d1:i"=>\$d1,
      "d2:i"=>\$d2,
      "a:i"=>\$a,
);

if(@ARGV==0){
     	prtHelp();
	exit;
}else{
	if($ARGV[0] =~ /(.*)\_rmdup.bam/){
		$prefix = $1;
	}else{
		print "\nError: The input file is not correct in format\!\n\n";
		print "argv0 = $ARGV[0]\n";
		exit;
	}
}

#print "prefix = $prefix\n";

unless($m){$m=1;}
unless($bq){$bq=20;}
unless($n){$n=5;}
unless($d1){$d1=5;}
unless($d2){$d2=6;}
unless($a){$a=3;}

my $cmd;

$cmd = "samtools mpileup -g -Q $bq -t DPR -f $refseqfile $prefix\_rmdup.bam > $prefix.bcf";
system($cmd);
$cmd = "bcftools call -m -V indels -T parent1.abxaa.5snps.blocks.loc -f GQ $prefix.bcf > $prefix\_p1gc.vcf";
system($cmd);
$cmd = "bcftools call -m -V indels -T parent2.aaxab.5snps.blocks.loc -f GQ $prefix.bcf > $prefix\_p2gc.vcf";
system($cmd);

$cmd = "perl extractprogenygt.pl $prefix\_p1gc.vcf parent1.abxaa.5snps.blocks | awk '\$0\!~/*/' | perl blocknumfilter.pl -L 5 - > $prefix\_p1gc.loc.5snps.hap";
system($cmd);
$cmd = "perl extractprogenygt.pl $prefix\_p2gc.vcf parent2.aaxab.5snps.blocks | awk '\$0\!~/*/' | perl blocknumfilter.pl -L 5 - > $prefix\_p2gc.loc.5snps.hap";
system($cmd);

$cmd = "perl calculatingGCs.pl $prefix\_p1gc.loc.5snps.hap";
system($cmd);
$cmd = "perl calculatingGCs.pl $prefix\_p2gc.loc.5snps.hap";
system($cmd);

if(-e "parent1.longhap.loc" && -e "parent2.longhap.loc"){
	$cmd = "bcftools call -m -V indels -T parent1.longhap.loc -f GQ $prefix.bcf > $prefix\_p1.longhap.vcf";
	system($cmd);
	$cmd = "bcftools call -m -V indels -T parent2.longhap.loc -f GQ $prefix.bcf > $prefix\_p2.longhap.vcf";
	system($cmd);

	$cmd = "perl extractprogeny_longhap.gt.pl $prefix\_p1.longhap.vcf parent1.long.haplotype | awk '\$0\!~/*/' > $prefix\_p1.longhap.gt";
	system($cmd);
	$cmd = "perl extractprogeny_longhap.gt.pl $prefix\_p2.longhap.vcf parent2.long.haplotype | awk '\$0\!~/*/' > $prefix\_p2.longhap.gt";
	system($cmd);

	$cmd ="perl calculatingCOs.pl $prefix\_p1.longhap.gt";
	system($cmd);
	$cmd ="perl calculatingCOs.pl $prefix\_p2.longhap.gt";
	system($cmd);
}

exit;
