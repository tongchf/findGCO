#!usr/bin/perl -w

my ($DP,$ALLEN1,$ALLEN2,$GQ,$key,$value,$OUTname);
my %hash1;

if(@ARGV < 2){
	die "Uage: perl extractvcf.pl <input.vcf> <input.haplotype>\n";
}

if($ARGV[0]=~/(.*)\.vcf/){
	$OUTname="$1_het.stat";
}else{
	die "Error: please check the name of vcf file.\n";
}

open(IN,"<$ARGV[0]");
open(IN2,"<$ARGV[1]");
open(OUT1,">$OUTname");

while(<IN>){
	chomp$_;
      	unless($_=~/^#/){
       		if(/0\/1/){
        		if( /.*DP=(\d+);.*0\/1:.*:(\d+),(\d+):(\d+)/){
             			$DP=$1;
	             		$ALLEN1=$2;
        	     		$ALLEN2=$3;
             			$GQ=$4; 
          			my ($var1,$var2,undef,$var3,$var4)=split/\t/,$_,6;
	             		$key="$var1\t$var2";
        	     		$value="$DP\t$var3\t$ALLEN1\t$var4\t$ALLEN2\t$GQ";
             			$hash1{$key}=$value;
          			print OUT1 "$key\t$value\n";
	        	}
       		}elsif(/1\/2/){
        		if( /.*DP=(\d+);.*1\/2:.*:(\d+),(\d+),(\d+):(\d+)/){
             			$DP=$1;
	             		$ALLEN1=$3;
        	     		$ALLEN2=$4;
             			$GQ=$5;
          			my ($var1,$var2,undef,undef,$var3)=split/\t/,$_,6;
	             		$key="$var1\t$var2";
        	  		my @gt=split/,/,$var3;
             			$value="$DP\t$gt[0]\t$ALLEN1\t$gt[1]\t$ALLEN2\t$GQ";
             			$hash1{$key}=$value;
	          		print OUT1 "$key\t$value\n";
        		}
	       	}
      	}
}

while(<IN2>){
	chomp $_;
       	if(/M1/){
        	my(undef,$var1,$var2,$var3,$var4)=split/\t/,$_;
	        my $marker="$var1\t$var2";
        	if(exists $hash1{$marker}){
        		my @lin=split/\t/,$hash1{$marker};
	             	if($var3 eq $lin[1]){
        	     		print "M\t$marker\t$var3\t$var4\t$lin[2]\t$lin[4]\t$lin[0]\t$lin[5]\n";
             		}else{
				print "M\t$marker\t$var3\t$var4\t$lin[4]\t$lin[2]\t$lin[0]\t$lin[5]\n";
	             	}
   		}else{
			print "M\t$marker\t$var3\t$var4\t*\t*\t*\t*\n";
		}
       	}else{
		print "$_\n";
	}
}

close IN;
close IN2;
