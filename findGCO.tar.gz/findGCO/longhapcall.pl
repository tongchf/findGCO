#!usr/bin/perl -w 
use strict;

if(@ARGV < 4){
	print "\nUsage: perl honghapcall.pl <input.blocks> <input.rev.blocks> <map.phase> <output.long.haplotype>\n\n";
	exit;
}

open(BLOCK,"<$ARGV[0]") or die;
open(BLOCK2,"<$ARGV[1]") or die;
open(Linkage,"<$ARGV[2]") or die;
open(OUTPUT,">$ARGV[3]") or die;

my(%hash1,%hash2,%hash3);
my ($all,$bl,$key,$gt,$n,$phase);
my (@block,@lin,@allels,@wds);
my ($var1,$var2,$var3,$var4);
my ($i,$nblk,$blkn);
local $/;

$all = <BLOCK>;
@block = split /\n\/\/\n/,$all;

foreach(@block){
 	chomp $_;
      	$bl = $_;
      	@lin = split /\n/,$_;
      	foreach(@lin){
		unless(/PS/){
       			(undef,$var1,$var2,$var3,$var4) = split /\t/,$_;
        		$key = "$var1\t$var2";
        		$gt = "$var3$var4"; 
        		$hash1{$key} = $gt;
        		$hash2{$key} = $bl;
		}
      	}
}

local $/;
$all = <BLOCK2>;
@block = split/\n\/\/\n/,$all;

foreach(@block){
      	chomp $_;
       	$bl = $_;
      	@lin = split /\n/,$_;
      	foreach(@lin){
        	(undef,$var1,$var2) = split /\t/,$_,4;
        	$key = "$var1\t$var2";
       		$hash3{$key} = $bl;
      }
}

local $/ = "\n";
my %mks = ();
my $chr;
$nblk = 1;
while( <Linkage> ){
    	chomp $_;
       	@lin = split /\t/,$_;
	if(@lin != 3){ next;}

	$var1 = $lin[0];
	$var2 = $lin[1];
	$var3 = $lin[2];
	$var3 =~ s/\W//g;          	
        $key = "$var1\t$var2";
	$mks{$var1} += 1;
	$chr = scalar (keys %mks);
        if( exists $hash1{$key} ){
		$phase = $hash1{$key};
		$blkn = "B$nblk";
           	if( $var3 eq $phase ){
			@block = split /\n/,$hash2{$key};
			$n = scalar @block;
			@wds = ();
			for($i=1;$i<$n;$i++){
				push @wds,[split /\t/,$block[$i]];
			}
			$n = $n - 1;
			
			for($i=0;$i<$n;$i++){
				$var4 = $wds[$n-1][2] - $wds[0][2] + 1;
				$var4 = "$wds[0][2]\t$wds[$n-1][2]\t$var4\t$blkn";
	               		print OUTPUT "$wds[$i][1]\t$wds[$i][2]\t";
	               		print OUTPUT "$wds[$i][3]\t$wds[$i][4]\t";
				if($key eq "$wds[$i][1]\t$wds[$i][2]"){
					$var4 = "$var4\tM$chr-$mks{$var1}";
				}else{
					$var4 = "$var4\tNA";
				}
				print OUTPUT "$var4\n";
			}
		}else{ 
			@block = split /\n/,$hash3{$key};
			$n = scalar @block;
			@wds = ();
			for($i=1;$i<$n;$i++){
				push @wds,[split /\t/,$block[$i]];
			}
			$n = $n - 1;
			
			for($i=0;$i<$n;$i++){
				$var4 = $wds[$n-1][2] - $wds[0][2] + 1;
				$var4 = "$wds[0][2]\t$wds[$n-1][2]\t$var4\t$blkn";
	               		print OUTPUT "$wds[$i][1]\t$wds[$i][2]\t";
	               		print OUTPUT "$wds[$i][3]\t$wds[$i][4]\t";
				if($key eq "$wds[$i][1]\t$wds[$i][2]"){
					$var4 = "$var4\tM$chr-$mks{$var1}";
				}else{
					$var4 = "$var4\tNA";
				}
				print OUTPUT "$var4\n";
			}
		}
		$nblk++;
         }else{ 
		@allels = split "",$var3;
               	print OUTPUT "$key\t$allels[0]\t$allels[1]\t$var2\t$var2\t1\tNA\tM$chr-$mks{$var1}\n";
         }
}

close BLOCK;
close BLOCK2;
close Linkage;     
close OUTPUT;
exit;

