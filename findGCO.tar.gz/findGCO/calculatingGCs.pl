#!/usr/bin/perl -w
use strict;

if(@ARGV<1){
	die "\nUsage: perl calculatingGCs.pl <input.loc.5snps.hap>\n\n";
}

open(IN,"<$ARGV[0]") || die;

my @x;
my @linedata;
my $n;
my $outfile;

$outfile = "$ARGV[0]\_gc.rst";

open(OUT,">$outfile");

while(<IN>){
	chop $_;
	@linedata = split /\t/,$_;
	push @x,[@linedata];
	$n++; 
}
close(IN);

my (@begin,@end,@st,@ed);
my ($i,$j,$k,$nb);
my ($stj,$edj);

for($i=0;$i<$n;$i++){
	if($x[$i][0] =~ /PS/){
		push @begin,$i;
	}
	if($x[$i][0] =~ /\/\//){
		push @end,$i;
	}	
}

my (@blki,@c,@uc,@is,$nis);
my ($n2,$dm,$blklength,$nuc,$c123);
my (@c0,@bk0,$nc0);
my %hash;
my (@rst0,@rst);
my ($mxd,$ngc,$sum0,$sum1);

$n2 = scalar @begin;
$blklength = 0;
$ngc = 0;
@rst = ();
for($i=0;$i<$n2;$i++){
	@blki = ();
	for($j=($begin[$i]+1);$j<$end[$i];$j++){
		push @blki, [@{$x[$j]}];
	}
	$dm = $#blki + 1;
	$blklength += $blki[$dm-1][2] - $blki[0][2] + 1;
	@c = ();
	for($j=0;$j<$dm;$j++){
		if($blki[$j][5] eq $blki[$j][3]){
			push @c,0;
		}else{
			push @c,1;
		}
	}
	%hash = ();
	@uc = grep{++$hash{$_}<2}@c;
	$nuc = scalar @uc;
	if($nuc == 1){
		next;
	}
	@is = (-1);
	$c123 = join("",@c[0..2]);
	if($c123 eq "011" || $c123 eq "100"){
		push @is,0;
	}	
	for($j=0;$j<($dm-2);$j++){	
		$c123 = join("",@c[$j..($j+2)]);
		if($c123 eq "010" || $c123 eq "101"){
			push @is,$j + 1;
		}
	}
	$c123 = join("",@c[($dm-3)..($dm-1)]);
	if($c123 eq "110" || $c123 eq "001"){
		push @is,$dm-1;
	}
	push @is,$dm;
	$nis = scalar @is;
	$nis = $nis - 1;
	$dm = $dm -$nis + 1;
	@c0 = ();
	@bk0 = ();
	for($j=0;$j<$nis;$j++){
		for($k=($is[$j]+1);$k<$is[$j+1];$k++){
			push @c0,$c[$k];
			push @bk0,[@{$blki[$k]}];	
		}
	}
	@st = (0);
	@ed = ();
	for($j=0;$j<($dm-1);$j++){
		$c123 = join("",$c0[$j],$c0[$j+1]);
		if($c123 eq "01" || $c123 eq "10"){
			push @st,$j+1;
			push @ed,$j;
		}
	}
	push @ed,$dm-1;
	$nb = scalar @st;
	if($nb < 3){
		next;
	}
	@rst0 = ();
	for($j=0;$j<$nb;$j++){
		$stj = $bk0[$st[$j]][2];
		$edj = $bk0[$ed[$j]][2];
		if($j != 0 && $j != ($nb-1)){
			$mxd = $bk0[$ed[$j]+1][2]-$bk0[$st[$j]-1][2]-1;
		}else{
			$mxd = -1;
		}
		push @rst0,[$bk0[0][1],$c0[$st[$j]],$stj,$edj,$ed[$j]-$st[$j]+1,$edj-$stj+1,$mxd,"N"];
	}
	if($rst0[0][1] == 1 && $rst0[$nb-1][1] == 1){
		for($j=1;$j<($nb-1);$j++){
			if($rst0[$j][1] == 0){
				$rst0[$j][7] = "Y";
				$ngc++;
			}
		}
	}
	if($rst0[0][1] == 0 && $rst0[$nb-1][1] == 0){
		for($j=1;$j<($nb-1);$j++){
			if($rst0[$j][1] == 1){
				$rst0[$j][7] = "Y";
				$ngc++;
			}
		}
	}
	if($rst0[0][1]+$rst0[$nb-1][1] == 1){
		$sum0 = 0;
		$sum1 = 0;
		for($j=0;$j<$nb;$j++){
			if($rst0[$j][1] == 0){
				$sum0 = $sum0 + $rst0[$j][5];
			}else{
				$sum1 = $sum1 + $rst0[$j][5];
			}
		}
		if($sum0 < $sum1){
			for($j=1;$j<($nb-1);$j++){
				if($rst0[$j][1] == 0){
					$rst0[$j][7] = "Y";
					$ngc++;
				}
			}
		}else{
			for($j=1;$j<($nb-1);$j++){
				if($rst0[$j][1] == 1){
					$rst0[$j][7] = "Y";
					$ngc++;
				}
			}
		}
	}
	
	for($j=0;$j<$nb;$j++){
		print OUT "@{$rst0[$j]}\n";
	}
	print OUT "\/\/ \/\/ \/\/ \/\/ \/\/ \/\/ \/\/ \/\/\n";
}

close OUT;

exit;

