#!/usr/bin/perl -w
use strict;
use warnings;
use Data::Dumper;
use Parallel::ForkManager;
use Excel::Writer::XLSX;
use Statistics::Descriptive;

open(PRS,"<parameters.txt") || die "\nError\! This program needs a parameter file,namely \"parameters.txt\".\n\n";

my $line;
my %prs;
my ($str0,$str1,$str2);
my $np;
my ($i,$j,$k);
my $mapflag = 1;

$np = 0;
while(<PRS>){
	if(/:/){
		chop $_;
		($str1,$str2) = split /:/,$_;
		if($str1 =~ /\s*(\S+)\s*/){
			$str1 = $1;
			if($str2 =~ /\s*(\S+\s+\S+)\s*/ || 
			   $str2 =~ /\s*(\S+)\s*/){
				$str2 = $1;
				$prs{$str1} = $str2;
				if($str1 =~ /PROGENY/){
					$np++;
				}
			}
		}
	}
}
close PRS;

my ($bwafold,$samtoolsfold,$bcftoolsfold,$picardfold);
my ($fastqfold,$refseqfold,$linkmapfold);

if( exists( $prs{BWA_FOLD}) ){
	$bwafold = $prs{"BWA_FOLD"};
}else{
	die "Error! Please check the path of bwa in \"parameters.txt\".\n";
}

if(exists($prs{"SAMTOOLS_FOLD"})){
	$samtoolsfold = $prs{"SAMTOOLS_FOLD"};
}else{
	die "Error! Please check the path of SAMtools in \"parameters.txt\".\n";
}

if(exists($prs{"BCFTOOLS_FOLD"})){
	$bcftoolsfold = $prs{"BCFTOOLS_FOLD"};
}else{
	die "Error! Please check the path of bcftools in \"parameters.txt\".\n";
}

if(exists($prs{"PICARDTOOLS_FOLD"})){
	$picardfold = $prs{"PICARDTOOLS_FOLD"};
}else{
	die "Error! Please check the path of picard-tools in \"parameters.txt\".\n";
}

if(exists($prs{"FASTQ_FOLD"})){
	$fastqfold = $prs{"FASTQ_FOLD"};
}else{
	die "Error! Please check the path of fastq files in \"parameters.txt\".\n";
}

if(exists($prs{"REFERENCE_FOLD"})){
	$refseqfold = $prs{"REFERENCE_FOLD"};
}else{
	die "Error! Please check the path of reference sequence file in \"parameters.txt\".\n";
}

if(exists($prs{"LINKAGEMAP_FOLD"})){
	$linkmapfold = $prs{"LINKAGEMAP_FOLD"};
}else{
	$mapflag = 0;
	warn "The path of linkage map files is wrong or does not exist in \"parameters.txt\".\n";
}

unless(-d $bwafold){
	die "Error! The path of bwa is wrong or does not exist.\n";
}

unless(-d $samtoolsfold){
	die "Error! The path of SAMtools is wrong or does not exist.\n";
}

unless(-d $bcftoolsfold){
	die "Error! The path of bcftools is wrong or does not exist.\n";
}

unless(-d $picardfold){
	die "Error! The path of picard-tools is wrong or does not exist.\n";
}

unless(-d $fastqfold){
	die "Error! The path of fastq files is wrong or does not exist.\n";
}

unless(-d $refseqfold){
	die "Error! The path of reference file is wrong or does not exist.\n";
}

my ($refseqfile,$p11fq,$p12fq,$p21fq,$p22fq);
my @prg1fq;
my @prg2fq;
my ($p1map,$p2map);

if(exists($prs{"REFSEQFILE"})){
	$refseqfile = $prs{"REFSEQFILE"};
	$str0 = $refseqfold."\/".$refseqfile;
	unless(-e $str0){
		die "Error\! The reference sequence file is wrong or does not exist.\n";
	}
}else{
	die "Error! Please check the line of REFSEQFILE in \"parameters.txt\".\n";
}

if(exists($prs{"PARENT1MAP"})){
	$p1map = $prs{"PARENT1MAP"};
	$str0 = $linkmapfold."\/".$p1map;
	unless(-e $str0){
		$mapflag = 0;
		warn "The linkage map file of parent 1 is wrong or does not exist.\n";
	}
}else{
	$mapflag = 0;
	warn "Please check the line of PARENT1MAP in \"parameters.txt\".\n";
}

if(exists($prs{"PARENT2MAP"})){
	$p2map = $prs{"PARENT2MAP"};
	$str0 = $linkmapfold."\/".$p2map;
	unless(-e $str0){
		$mapflag = 0;
		warn "The linkage map file of parent 2 is wrong or does not exist.\n";
	}
}else{
	$mapflag = 0;
	warn "Please check the line of PARENT2MAP in \"parameters.txt\".\n";
}

if(exists($prs{"PARENT1"})){
	($p11fq,$p12fq) = split /\s+/,$prs{"PARENT1"};
	$str1 = "$fastqfold\/$p11fq";
	$str2 = "$fastqfold\/$p12fq";
	unless(-e $str1){
		die "Error\! The first fastq file of parent 1 is wrong or does not exist.\n";
	}
	unless(-e $str2){
		die "Error\! The second fastq file of parent 1 is wrong or does not exist.\n";
	}
}else{
	die "Error! Please check the line of PARENT1 in \"parameters.txt\".\n";
}

if(exists($prs{"PARENT2"})){
	($p21fq,$p22fq) = split /\s+/,$prs{"PARENT2"};
	$str1 = "$fastqfold\/$p21fq";
	$str2 = "$fastqfold\/$p22fq";
	unless(-e $str1){
		die "Error\! The first fastq file of parent 2 is wrong or does not exist.\n";
	}
	unless(-e $str2){
		die "Error\! The second fastq file of parent 2 is wrong or does not exist.\n";
	}
}else{
	die "Error! Please check the line of PARENT2 in \"parameters.txt\".\n";
}

for($i = 1;$i <= $np;$i++){
	$str0 = "PROGENY$i";
	if(exists($prs{$str0})){
		($prg1fq[$i-1],$prg2fq[$i-1]) = split /\s+/,$prs{$str0};
		$str1 = "$fastqfold\/$prg1fq[$i-1]";
		$str2 = "$fastqfold\/$prg2fq[$i-1]";
		unless(-e $str1){
			die "Error\! The first fastq file of progeny $i is wrong or does not exist.\n";
		}
		unless(-e $str2){
			die "Error\! The second fastq file of progeny $i is wrong or does not exist.\n";
		}
	}else{
		die "Error! Please check the line of PROGENY$i in \"parameters.txt\".\n";
	}
}

my ($threads,$alpha,$mq,$bq,$gq);

if(exists($prs{"THREADS"})){
	$threads = $prs{"THREADS"};
	unless( $threads =~ /\d+/ ){
		die "Error\! The number of threads is wrong.\n";
	}
}else{
	die "Error! Please check the line of THREADS in \"parameters.txt\".\n";
}

if(exists($prs{"ALPHA"})){
	$alpha = $prs{"ALPHA"};
	unless( $alpha =~ /0.\d+/ ){
		die "Error\! The value of ALPHA is wrong.\n";
	}
}else{
	die "Error! Please check the line of ALPHA in \"parameters.txt\".\n";
}

if(exists($prs{"MQ"})){
	$mq = $prs{"MQ"};
	unless( $mq =~ /\d+/ ){
		die "Error\! The value of MQ is wrong.\n";
	}
}else{
	die "Error! Please check the line of MQ in \"parameters.txt\".\n";
}

if(exists($prs{"BQ"})){
	$bq = $prs{"BQ"};
	unless( $bq =~ /\d+/ ){
		die "Error\! The value of BQ is wrong.\n";
	}
}else{
	die "Error! Please check the line of BQ in \"parameters.txt\".\n";
}

if(exists($prs{"GQ"})){
	$gq = $prs{"GQ"};
	unless( $bq =~ /\d+/ ){
		die "Error\! The value of GQ is wrong.\n";
	}
}else{
	die "Error! Please check the line of GQ in \"parameters.txt\".\n";
}

my $path;

$path = $ENV{PATH};

unless($bwafold =~ $path){
	$path = "$bwafold:$path";
}
unless($samtoolsfold =~ $path){
	$path = "$samtoolsfold:$path";
}
unless($bcftoolsfold =~ $path){
	$path = "$bcftoolsfold:$path";
}
$ENV{PATH} = $path;

my $prfx;
my ($n0,$n1);
my $cmd;

###############################     Mapping     ###################################

$prfx = "parent1";
$n0 = 0;
if(-e "$prfx.sam"){
	$n0 = readpipe("wc -l '$prfx.sam' \| awk \'{print \$1}\'");
	chop $n0;
}
$str0 = "$refseqfold\/$refseqfile";
$str1 = "$fastqfold\/$p11fq";
$str2 = "$fastqfold\/$p12fq";
$n1 = readpipe("wc -l $str1 \| awk \'{print \$1}\'");
$n1 = $n1/2;
if($n0 < $n1){
	$cmd = "perl mapping.pl -d $prfx -f $str0 -t $threads $str1 $str2";
	print "Performing: $cmd\n";
	system($cmd);
}

$prfx = "parent2";
$n0 = 0;
if(-e "$prfx.sam"){
	$n0 = readpipe("wc -l '$prfx.sam' \| awk \'{print \$1}\'");
	chop $n0;
}
$str1 = "$fastqfold\/$p21fq";
$str2 = "$fastqfold\/$p22fq";
$n1 = readpipe("wc -l $str1 \| awk \'{print \$1}\'");
$n1 = $n1/2;
if($n0 < $n1){
	$cmd = "perl mapping.pl -d $prfx -f $str0 -t $threads $str1 $str2";
	print "Performing: $cmd\n";
	system($cmd);
}

for($i=1;$i<=$np;$i++){
	$prfx = "progeny$i";
	$n0 = 0;
	if(-e "$prfx.sam"){
		$n0 = readpipe("wc -l '$prfx.sam' \| awk \'{print \$1}\'");
		chop $n0;
	}
	$str1 = "$fastqfold\/$prg1fq[$i-1]";
	$str2 = "$fastqfold\/$prg2fq[$i-1]";
	$n1 = readpipe("wc -l $str1 \| awk \'{print \$1}\'");
	$n1 = $n1/2;
	if($n0 < $n1){
		$cmd = "perl mapping.pl -d $prfx -f $str0 -t $threads $str1 $str2";
		print "Performing: $cmd\n";
		system($cmd);
	}
}

######################      Filtering      #################################

my $maxproc;
my @iprfxs;
my ($out1,$out2,$out3,$out4,$out5);
my ($pid,$pm);

if($threads>($np+2)){
	$maxproc = $np + 2;
}else{
	$maxproc = $threads;
}
@iprfxs = ("parent1","parent2");

for($i=1;$i<=$np;$i++){
	push(@iprfxs,"progeny$i");
}

$pm = new Parallel::ForkManager($maxproc);
for($i=0;$i<$maxproc;$i++){
	$pid = $pm->start and next;
	$out1 = "$iprfxs[$i].sam";
	system("perl filtering.pl -a $alpha $out1");
	$out2 = "$iprfxs[$i]\_filtered.sam";
	$out3 = "$iprfxs[$i]\_filtered.bam";
	$out4 = "$iprfxs[$i]\_filtered.sorted";
	system("samtools view -b -S -o $out3 $out2");
	system("samtools sort $out3 $out4");
	$out5 = "$iprfxs[$i]\_rmdup.bam";
	system("java -Xmx8g -jar $picardfold\/MarkDuplicates.jar REMOVE_DUPLICATES=true I=$out4.bam O=$out5 M=$out5.metrics");
	system("samtools index $out5");
	$pm->finish;
}
$pm->wait_all_children;

#####################     Haplotyping    ###############################

$str1 = "parent1_rmdup.bam";
$str2 = "parent2_rmdup.bam";
if($mapflag == 1){
#	$p1map = $linkmapfold."\/".$p1map;
#	$p2map = $linkmapfold."\/".$p2map;
	$cmd = "perl haplotyping.pl -f $refseqfold\/$refseqfile -Q $bq -G $gq -m1 $linkmapfold\/$p1map -m2 $linkmapfold\/$p2map $str1 $str2";
}else{
	$cmd = "perl haplotyping.pl -f $refseqfold\/$refseqfile -Q $bq -G $gq $str1 $str2";
}

system($cmd);

########################################################################

###################    Counting GCs and COs  ###########################

my @progenybamfiles;
@progenybamfiles = ();
if($np>$threads){
	$maxproc = $threads;
}else{
	$maxproc = $np;
}

for($i=1;$i<=$np;$i++){
	push(@progenybamfiles,"progeny$i\_rmdup.bam");
}

$pm = new Parallel::ForkManager($maxproc);
for($i=0;$i<$maxproc;$i++){
	my $pid = $pm->start and next;
	system("perl countingGCOs.pl -Q $bq -f $refseqfold\/$refseqfile $progenybamfiles[$i]");
	$pm->finish;
}
$pm->wait_all_children;

my ($workbook,$sheet,$pi,@linedata);
my ($prgfile,@prgname,@cos);
my (%hashi,%hash,$key,$value);
my ($parenti,@x,@x1,$total,$aver,$n);
my (@contigs,@chrs,$nc,$clength);

## generating excel files for summaring GC results.

## reading contig information from a vcf file.

open(CNT,"<progeny1_p1gc.vcf") || die "Error! progeny1_p1gc.vcf does not exist.\n";
$n = 0;
$clength = 0;
while(<CNT>){
	if(/##/){
		if(/.*ID=(\w+),length=(\d+).*/){
			push @contigs,[$1,$2];
			$clength += $2;
			$n++;
		}
	}else{
		last;
	}
} 
close CNT;

$clength *= 0.01;
for($i=0;$i<$n;$i++){
	if($contigs[$i][1] > $clength){
		push @chrs,$contigs[$i][0];
	}
}
$nc = scalar @chrs;

for ($i=0;$i<$np;$i++){
	$j = 0;
	while($j<length($prg1fq[$i])){
		if(substr($prg1fq[$i],$j,1) ne substr($prg2fq[$i],$j,1)){
			last;
		}
		$j++;
	}
	$prfx = substr($prg1fq[$i],0,$j);
	$prfx =~ s/[\_\-.]+$//;
	push @prgname,$prfx;
}

my $flag;
for($parenti=1;$parenti<3;$parenti++){
	$prfx = "parent$parenti"."GCs.xlsx";
	$workbook = Excel::Writer::XLSX->new($prfx);
	for ($i=0;$i<$np;$i++){
		$pi = $i + 1;
		$prgfile = "progeny$pi\_p$parenti"."gc.loc.5snps.hap\_gc.rst";
		if(-e $prgfile){
			$sheet = $workbook->add_worksheet($prgname[$i]);
			$sheet->write(0,0,'RefSeq');
			$sheet->write(0,1,'2-19bp');
			$sheet->write(0,2,'20-200bp');
			$sheet->write(0,3,'200bp-1kb');
			$sheet->write(0,4,'1-2kb');
			$sheet->write(0,5,'2-10kb');
			$sheet->write(0,6,'>=10kb');
			$sheet->write(0,7,'TotalGCs');
			$sheet->write(0,8,'GClength');
			for($j=0;$j<$nc;$j++){
				$sheet->write($j+1,0,$chrs[$j]);
			}
			$sheet->write($nc+1,0,'Others');
			$sheet->write($nc+2,0,'Total');
			for($j=0;$j<($nc+2);$j++){
				for($k=0;$k<8;$k++){
					$x[$i][$j][$k] = 0;
				}
			}
			open(GCRST,"<$prgfile");
			while(<GCRST>){
				chop $_;
				if(/\/\//){ next; }
				@linedata = split /\s+/,$_;
				$flag = 0;
				for($j=0;$j<$nc;$j++){
					if($chrs[$j] eq $linedata[0]){
						$flag = 1;
						if($linedata[7] =~ /Y/){
							$clength = ($linedata[5]+$linedata[6])/2;
							if($clength < 20 ){ 
								$x[$i][$j][0]++;
								last;
							}	
							if($clength >= 20 && $clength < 200 ){ 
								$x[$i][$j][1]++;
							 	$x[$i][$j][7] += $clength;
								last;
							}	
							if($clength >= 200 && $clength < 1000 ){ 
								$x[$i][$j][2]++;
							 	$x[$i][$j][7] += $clength;
								last;
							}	
							if($clength >= 1000 && $clength < 2000 ){ 
								$x[$i][$j][3]++;
							 	$x[$i][$j][7] += $clength;
								last;
							}	
							if($clength >= 2000 && $clength < 10000 ){ 
								$x[$i][$j][4]++;
								last;
							}	
							if($clength >= 10000 ){ 
								$x[$i][$j][5]++;
								last;
							}	
						}
					}					
				}
				if($flag == 1){ next; }
				if($linedata[7] =~ /Y/){
					$clength = ($linedata[5]+$linedata[6])/2;
					if($clength < 20 ){ 
						$x[$i][$nc][0]++;
						next;
					}	
					if($clength >= 20 && $clength < 200 ){ 
						$x[$i][$nc][1]++;
					 	$x[$i][$nc][7] += $clength;
						next;
					}	
					if($clength >= 200 && $clength < 1000 ){ 
						$x[$i][$nc][2]++;
						$x[$i][$nc][7] += $clength;
						next;
					}	
					if($clength >= 1000 && $clength < 2000 ){ 
						$x[$i][$nc][3]++;
					 	$x[$i][$nc][7] += $clength;
						next;
					}	
					if($clength >= 2000 && $clength < 10000 ){ 
						$x[$i][$nc][4]++;
						next;
					}	
					if($clength >= 10000 ){ 
						$x[$i][$nc][5]++;
					}	
				}
				
			}
			close GCRST;
			for($j=0;$j<=$nc;$j++){
				for($k=0;$k<6;$k++){
					$sheet->write($j+1,$k+1,$x[$i][$j][$k]);
				}
				$x[$i][$j][6] = $x[$i][$j][1] + $x[$i][$j][2] + $x[$i][$j][3];
				$sheet->write($j+1,7,$x[$i][$j][6]);
				$x[$i][$j][7] = $x[$i][$j][7]/$x[$i][$j][6];
				$sheet->write($j+1,8,$x[$i][$j][7]);
			}
			
			for($j=0;$j<7;$j++){
				$n1 = 0;
				for($k=0;$k<=$nc;$k++){
					$n1 += $x[$i][$k][$j];
				}
				$x[$i][$nc+1][$j] = $n1;
				$sheet->write($nc+2,$j+1,$n1);
			}
			$clength = 0;
			for($j=0;$j<=$nc;$j++){
				$clength += $x[$i][$j][6]*$x[$i][$j][7];
			}
			$x[$i][$nc+1][7] = $clength/$x[$i][$nc+1][6];
			$sheet->write($nc+2,8,$x[$i][$nc+1][7]);
		}
	}
	$sheet = $workbook->add_worksheet('Table1');
	$sheet->write(0,0,'RefSeq');
	for($j=0;$j<$nc;$j++){
		$sheet->write($j+1,0,$chrs[$j]);
	}
	$sheet->write($nc+1,0,'Others');
	$sheet->write($nc+2,0,'Total');
	for($j=0;$j<$np;$j++){
		$sheet->write(0,$j+1,$prgname[$j]);
	}
	$sheet->write(0,$np+1,'Average');
	$sheet->write(0,$np+2,'Std');

	for($i=0;$i<$np;$i++){
		for($j=0;$j<($nc+2);$j++){
			$x1[$j][$i] = $x[$i][$j][6];
		}
	}

	my $stat = Statistics::Descriptive::Full->new();
	for($i=0;$i<($nc+2);$i++){
		for($j=0;$j<$np;$j++){
			$sheet->write($i+1,$j+1,$x1[$i][$j]);
		}
		$stat->add_data(@{$x1[$i]});
		my $mean = $stat->mean();
		my $std = $stat->standard_deviation();
		$stat->clear();
		$sheet->write($i+1,$np+1,$mean);
		$sheet->write($i+1,$np+2,$std);
	}
	$sheet = $workbook->add_worksheet('Table2');
	$sheet->write(0,0,'RefSeq');
	$sheet->write(0,1,'2-19bp');
	$sheet->write(0,2,'20-200bp');
	$sheet->write(0,3,'200bp-1kb');
	$sheet->write(0,4,'1-2kb');
	$sheet->write(0,5,'2-10kb');
	$sheet->write(0,6,'>=10kb');
	$sheet->write(0,7,'TotalGCs');
	$sheet->write(0,8,'GClength');
	for($j=0;$j<$nc;$j++){
		$sheet->write($j+1,0,$chrs[$j]);
	}
	$sheet->write($nc+1,0,'Others');
	$sheet->write($nc+2,0,'Total');
	for($j=0;$j<($nc+2);$j++){
		for($k=0;$k<8;$k++){
			$x1[$j][$k] = 0;
			for($i=0;$i<$np;$i++){
				$x1[$j][$k] += $x[$i][$j][$k];
			}
			$x1[$j][$k] /= $np;
			$sheet->write($j+1,$k+1,$x1[$j][$k]);
		}
	}
		
	$sheet = $workbook->add_worksheet('Table3');
	$sheet->write(0,0,"Sample");
	$sheet->write(0,1,"Block number");
	$sheet->write(0,2,"Total length");
	my @xx = ();

	for($i=0;$i<$np;$i++){
		$pi = $i + 1;
		$prgfile = "progeny$pi\_p$parenti"."gc.loc.5snps.hap";
		open(HAP,"<$prgfile");
		$clength = 0;
		$n = 0;
		while(<HAP>){
			if(/PS/){
				@x1 = ();
				$n++;
				next;
			}
			@linedata = split /\t/,$_;
			push @x1,[@linedata];
			if(/\/\//){
				$n1 = $#x1;
				$clength += $x1[$n1-1][2] - $x1[0][2] + 1;
			}
		}	
		close HAP;
		$xx[$i][0] = $n;
		$xx[$i][1] = $clength;
	}
	$n = 0;
	$clength = 0;
	for($i=0;$i<$np;$i++){
		$sheet->write($i+1,0,$prgname[$i]);
		$sheet->write($i+1,1,$xx[$i][0]);
		$sheet->write($i+1,2,$xx[$i][1]);
		$n += $xx[$i][0];
		$clength += $xx[$i][1];
	}
	$n /= $np;
	$clength /= $np;
	$sheet->write($np+1,0,"Average");
	$sheet->write($np+1,1,$n);
	$sheet->write($np+1,2,$clength);
}

## generating excel files for summaring CO results.

if($mapflag == 0){
	exit;
}

for($parenti=1;$parenti<3;$parenti++){
	%hash = ();
	$prfx = "parent$parenti"."COs.xlsx";
	$workbook = Excel::Writer::XLSX->new($prfx);
	for ($i=0;$i<$np;$i++){
		$pi = $i + 1;
		$prgfile = "progeny$pi\_p$parenti.longhap.gt\_co.rst";
		unless(-e $prgfile){ 
			exit;
		}
		$sheet = $workbook->add_worksheet($prgname[$i]);
		$sheet->write(0,0,'Chromosome');
		$sheet->write(0,1,'Start');
		$sheet->write(0,2,'End');
		$sheet->write(0,3,'Phase');
		$sheet->write(0,4,'Length');
		$sheet->write(0,5,'Discription');
		%hashi = ();
		open(CORST,"<$prgfile");
		$j=1;
		while( <CORST> ){
			chop $_;
			if(/\/\//){
				for($k=0;$k<6;$k++){
					$sheet->write($j,$k," ");
				}
			}else{
				@linedata = split /\t/,$_;
				for($k=0;$k<6;$k++){
					$sheet->write($j,$k,$linedata[$k]);
				}
				++$hashi{$linedata[0]};
			}
			$j++;
		}
		close CORST;
		foreach $key (keys %hashi){
			if(exists($hashi{$key})){
				$value = $hashi{$key};
				$value = $value - 1;
			}else{
				$value = -1;
			}
			if($i == 0){
				$hash{$key} = "$value";
			}else{
				$hash{$key} ="$hash{$key}\t$value"; 
			}
		}
	}

	$sheet = $workbook->add_worksheet('Summary');
	$sheet->write(0,0,'Sample');
	$sheet->write(0,$np+1,'Average');
	for($i=0;$i<$np;$i++){
		$sheet->write(0,$i+1,$prgname[$i]);
	}
	$n = 0;
	@x = ();
	foreach $key (sort keys %hash){
		$value = $hash{$key};
		@linedata = split /\t/,$value;
		push @x,[@linedata];
		$n++;
		for($j=0;$j<=$np;$j++){
			$sheet->write($n,$j+1,$linedata[$j]);
		}
		$sheet->write($n,0,$key);
	}
	for($i=0;$i<$n;$i++){
		$aver = 0;
		$n1 = 0;
		for($j=0;$j<$np;$j++){
			if($x[$i][$j] != -1){
				$aver += $x[$i][$j];
				$n1++;
			}
		}
		$aver = $aver/$n1;
		$sheet->write($i+1,$np+1,$aver);
	}
	$sheet->write($n+1,0,'Total');
	$total = 0;
	for($i=0;$i<$np;$i++){
		$n1 = 0;
		for($j=0;$j<$n;$j++){
			if($x[$j][$i] != -1){
				$n1 += $x[$j][$i];
			}
		}
		$sheet->write($n+1,$i+1,$n1);
		$total += $n1;
	}
	$sheet->write($n+1,$np+1,$total);
}

#######################################################################

exit;
