#!usr/bin/perl -w 
use strict;
use Getopt::Long;

sub prthelp{
   print "\nThis program is for filtering,sorting and indexing the records of a sam file to generate a bam file. Please add the paths of samtools and bcftools to the environment variable of PATH.\n";
   print "\n";
   print "Usage: perl filtering.pl [Options] <input.sam>\n";
   print "\n";
   print "Options:\n";
#   print "        -d <string> the path of picard-tools (required)\n";
   print "        -a <float> the maximum percentage of edit distance to a single read length [0.08]\n";
   print "\n";
}

my ($picardpath,$alpha);
GetOptions(
#        "d:s"=>\$picardpath,
        "a:f"=>\$alpha
);

unless($alpha){ $alpha = 0.08; }

if(@ARGV < 1 ){
	prthelp();
	die "Error: No input files are provided\n"; 
}

my $prfx ;

if( $ARGV[0] =~ /(.*)\.sam$/){
	$prfx = $1;
}else{
	die "Error: The input file is not a sam file.\n";
}
my $out1 = "$prfx\_filtered.sam";
print "prfx = $out1\n";

open(INPUT,"<$ARGV[0]")|| die "could not open the input file\n";
open(OUT1,">$out1");

my @raw;
my $lth;
my $str;
my $readlth;
my ($nm,$as,$xs);
my ($nm0,$as0);
while(<INPUT>){
	chomp $_;
	my @raw=split(/\t/,$_);
   	my $lth=scalar @raw;
    	if( $raw[0] =~ /@/ ){
		print OUT1 "$_\n";
	}else{
		if($raw[2] =~ /\*/){ next; }
		$str = join("  ",@raw[11..($lth-1)]);
		if($str =~ /.*NM:i:(\d+).*AS:i:(\d+).*XS:i:(\d+).*/){
			$nm = $1;
			$as = $2;
			$xs = $3;
			$readlth = length( $raw[9] );
			$nm0 = $readlth * $alpha;
			$as0 = $readlth - $nm0*5;
			if($nm < $nm0 && $as > $as0 && $as > $xs){
				print OUT1 "$_\n";
			}	
		}
    	}
}
close OUT1;
close INPUT;

exit;
