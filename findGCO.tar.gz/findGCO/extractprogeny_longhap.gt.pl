#!usr/bin/perl -w
use strict;

my $prefix;
if(@ARGV < 2){
	die "Uage: perl extracprogenygt.pl <input.vcf> <parent.long.haplotype>\n";
}

if($ARGV[0]=~/(.*)\.vcf/){
	$prefix = $1;
}else{
	die "Error: please check the name of vcf file.\n";
}

open(IN1,"$ARGV[0]")or die;
open(IN2,"$ARGV[1]")or die;

my %hash;
my @lin;
my ($key,$dp,$allen1,$allen2,$gq);

while(<IN1>){
     	chomp $_;
      	if(/^#/){ next;}
      	@lin = split /\t/,$_,3;
      	$key = "$lin[0]\t$lin[1]";
       	if($_=~/0\/0:(\d+)/){
           	$dp = $1;
           	if( $dp > 4 ){
              		$hash{$key}="a";
           	}
       	}elsif($_=~/0\/1:.*:(\d+),(\d+):(\d+)/){
           	$allen1 = $1;
           	$allen2 = $2;
		$gq = $3;
           	if($allen1 > 2 && $allen2 > 2 && $gq > 30){
               		$hash{$key}="b";
           	}
      	}elsif($_=~/1\/1:.*:(\d+),(\d+):.*/){
           	$dp=$2;
           	if( $dp > 4 ){
              		$hash{$key}="a";
           	}
       	}elsif($_=~/1\/2:.*:(\d+),(\d+),(\d+):(\d+)/){
           	$allen1 = $2;
           	$allen2 = $3;
		$gq = $4;
           	if( $allen1 > 2 && $allen2 > 2 && $gq > 30){
               		$hash{$key}="b";
           	}
       	}
}

while(<IN2>){
      	chomp $_;
      	
        @lin = split /\t/,$_,4;
        $key = "$lin[0]\t$lin[1]";
        if( exists $hash{$key}){
          	print "$_\t$hash{$key}\n";
        }else{ 
		print "$_\t*\n";
	}
}

close IN1;
close IN2;
  
