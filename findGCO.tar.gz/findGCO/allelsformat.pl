#!usr/bin/perl -w
use strict;

open(IN,"<$ARGV[0]") or die;

my @lin;

while(<IN>){
	chomp $_;
      	if(/\/\/|PS/){
        	print "$_\n";
      	}elsif(/M/){
       		@lin=split/\t/,$_;
       		if( $lin[3] eq $lin[9]){
          		print "M\t$lin[1]\t$lin[2]\ta\tb\n";
       		}elsif( $lin[4] eq $lin[9]){
          		print "M\t$lin[1]\t$lin[2]\tb\ta\n";
       		}
      	}
}

close IN;
