#!usr/bin/perl -w


sub prthelp{
   print "\nThis program is for mapping PE reads to the reference sequences with bwa-0.7.12. Please add the folder of bwa to the environment variable of PATH.\n";
   print "\n";
   print "Usage: perl mapping.pl [Options] <In1.fq> <In2.fq>\n";
   print "\n";
   print "Options:\n";
   print "        -d <string> prefix of the output files (required)\n";
   print "        -f <file> reference file (required)\n";
   print "        -t <int> number of threads used in bwa mem [1]\n";
   print "\n";
}

use Getopt::Long;

my ($prefix,$reference,$t);
GetOptions(
        "d:s"=>\$prefix,
        "f:s"=>\$reference,
        "t:i"=>\$t
);

if(@ARGV < 2 ){
	prthelp();
	die "Error: No input files are provided\n"; 
}

$fileExist= -e "$reference.bwt";
unless($fileExist){
	system("bwa index $reference");
}

unless($t){
   $t=1;
}

system("bwa mem -t $t $reference $ARGV[0] $ARGV[1] > $prefix.sam");

exit;

