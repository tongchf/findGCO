#!usr/bin/perl -w


if(@ARGV < 2){
	die "\nUage: perl extracthomogt.pl <parent1.hap.loc_p2.vcf> <parent1.block.stat>
  or  perl extracthomogt.pl <parent2.hap.loc_p1.vcf> <parent2.block.stat>\n\n";
}

open(IN,"<$ARGV[0]") or die;
open(IN2,"<$ARGV[1]") or die;

my %hash;
my ($dp,$var1,$var2,$var3,$gt,$key);

while(<IN>){
	chomp $_;
     	if(/.*1\/1:.*:(\d+),(\d+):(\d+)/){
      		$dp=$2;
	       	($var1,$var2,undef,undef,$var3)=split/\t/,$_,6;
       		$key="$var1\t$var2";
	       	$gt=$var3;
       		if( $dp > 4 ){
       			$hash{$key}=$gt;
	       	}else{
			$hash{$key}="*";
		}
    	}elsif(/.*0\/0:(\d+)/){
       		$dp=$1;
       		($var1,$var2,undef,$var3,undef)=split/\t/,$_,6;
       		$key="$var1\t$var2";
       		$gt=$var3;
       		if( $dp > 4 ){
       			$hash{$key}=$gt;
       		}else{
			$hash{$key}="*";
		}
    	}
}

while(<IN2>){
     	chomp $_;
     	if(/M/){
       		my (undef,$var1,$var2)=split/\t/,$_,4;
       		my $name="$var1\t$var2";
       		if(exists$hash{$name}){
         		print "$_\t$hash{$name}\n";
       		}else{ 
			print "$_\t*\n";
		}
     	}else{
		print "$_\n";
	}
}

close IN;
close IN2;
       
     
