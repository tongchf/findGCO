#!/usr/bin/perl -w
use strict;

if(@ARGV<1){
	die "\nUsage: perl calculatingCOs.pl <progeny.longhap.gt>\n\n";
}

open(IN,"<$ARGV[0]") || die;

my @x;
my @linedata;
my $n;
my $outfile;
my %hash = ();
my $str;
my ($key,$value);
my ($i,$j,$k);
my (@bg,@ed,@co0,@co1,@co2);

$outfile = "$ARGV[0]\_co.rst";

open(OUT,">$outfile");

while(<IN>){
	chop $_;
	@linedata = split /\t/,$_;
	if($linedata[9] eq $linedata[2]){
		push @linedata,0;
	}else{
		push @linedata,1;
	}
	$key = $linedata[0];
	$str = join("\t",@linedata);
	if(exists $hash{$key}){
		$hash{$key} = "$hash{$key}\n$str";
	}else{
		$hash{$key} = $str;
	}
}
close(IN);

my ($nbe,$bi,$ei);
my ($start,$end);
my (@str,@str1,$nstr,@sbj,@sej,$bj,$ej,$nsbe);
my (@ls,$nls);
my (@infs,$infs0,$infstr,@u12,$nu12);
my ($key2,%hash2);
my $span;
my @co0rst;
my ($nc,$nc2);

foreach $key ( sort keys %hash ){
	@x = split /\n/,$hash{$key};
	$n = scalar @x;
	for($i=0;$i<$n;$i++){
		$x[$i] = [split "\t",$x[$i]];
	}
	@bg = (0);
	@ed = ();
	for($i=0;$i<($n-1);$i++){
		$str = $x[$i][10].$x[$i+1][10];
		if($str eq "01" || $str eq "10"){
			push @ed,$i;
			push @bg,$i+1;
		}
	}
	push @ed,$n-1;
	$nbe = scalar @bg;
	@co0 = ();
	for($i=0;$i<$nbe;$i++){
		$bi = $bg[$i];
		$ei = $ed[$i];
		@str = ();
		for($j=$bi;$j<=$ei;$j++){
			push @str,[$x[$j][7],$x[$j][8]];
		}
		$nstr = $ei-$bi+1;
		@sbj = (0);
		@sej = ();
		for($j=0;$j<($nstr-1);$j++){
			if($str[$j][0] ne $str[$j+1][0]){
				push @sej,$j;
				push @sbj,$j+1;
			}
		}
		push @sej,$nstr-1;
		$nsbe = scalar @sbj;
		@ls = ();
		$nls = 0;
		for($j=0;$j<$nsbe;$j++){
			$bj = $sbj[$j];
			$ej = $sej[$j];
			if($str[$bj][0] eq "NA"){
				for($k=$bj;$k<=$ej;$k++){
					push @ls,[$k,$k];
					$nls++;
				}
			}else{
				push @ls,[$bj,$ej];
				$nls++;
			} 
		}
	
		@infs = ();
		for($j=0;$j<$nls;$j++){
			$bj = $ls[$j][0];
			$ej = $ls[$j][1];
			@u12 = ();
			%hash2 = ();
			for($k=$bj;$k<=$ej;$k++){
				$key2 = "$str[$k][0]\t$str[$k][1]";
				if(++$hash2{$key2}<2){
					push @u12,[$str[$k][0],$str[$k][1]];
			
				}
			}
			$nu12 = $#u12 + 1;
			if($u12[0][0] ne "NA" && $nu12 == 2){
				if($u12[0][1] ne "NA"){
					$infs0 = $u12[0][0].$u12[0][1];
				}else{
					$infs0 = $u12[1][0].$u12[1][1];
				}
			}
			if($u12[0][0] ne "NA" && $nu12 == 1){
				$infs0 = $u12[0][0];
			}
			if($u12[0][0] eq "NA" ){
				$infs0 = $u12[0][1];
			}
			push @infs,$infs0;
		}

		$infstr = join ":",@infs;
		$span = $x[$ei][1] - $x[$bi][1] + 1;
		push @co0,[$x[$bi][0],$x[$bi][1],$x[$ei][1],$x[$bi][10],$span,$infstr];
	}
#	push @co0rst,[@co0];
	$nc = $#co0 + 1;
#	@ls = ();
	@co1 = ();
	for($j=0;$j<$nc;$j++){
		if($co0[$j][4] > 10000 || $co0[$j][5] =~ /.*M[0-9]+-[0-9]+.*/){
			push @co1,[@{$co0[$j]}];
		}
	}
	@bg = (0);
	@ed = ();
	$nc2 = $#co1 + 1;
	for($i=0;$i<($nc2-1);$i++){
		$str = $co1[$i][3].$co1[$i+1][3];
		if($str eq "01" || $str eq "10"){
			push @ed,$i;
			push @bg,$i+1;
		}
	}
	push @ed,$nc2-1;
	$nbe = scalar @bg;
	@co2 = ();
	for($j=0;$j<$nbe;$j++){
		$bj = $bg[$j];
		$ej = $ed[$j];
		$span = $co1[$ej][2] - $co1[$bj][1] + 1;
		@infs = ();
		for($k=$bj;$k<=$ej;$k++){
			push @infs,$co1[$k][5];
		}
		$infstr = join ":",@infs;
#		push @co2,[$co1[$bj][0],$co1[$bj][1],$co1[$ej][2],$co1[$bj][3],$span,$infstr];
		print OUT "$co1[$bj][0]\t$co1[$bj][1]\t$co1[$ej][2]\t$co1[$bj][3]\t$span\t$infstr\n";
	}
	print OUT "\/\/\n";
}
close OUT;
exit;

