#!usr/bin/perl -w 
use strict;

use Getopt::Long;

my $L;
GetOptions("L:i"=>\$L);

if(@ARGV<1){
	print "\nUsage: perl blocknumfilter.pl [Options] <input.blocks>\n";
	print "\nOptions:\n";
	print "\t-L <int>  the number of snps within a block\n\n";
	die "Error: no input files found\!\n\n";
}else{
	open(IN,"<$ARGV[0]") ||  die "\nError: cannot find the input file\!\n\n"
}

unless($L){$L = 2;}

local $/;
my $all = <IN>;
my @block = split/\n\/\/\n/,$all;

foreach(@block){
      chomp $_;
      my @lin=split/\n/,$_;
      if(@lin > $L){print "$_\n\/\/\n";}
}

close IN;

exit;
