#!usr/bin/perl -w
use strict;
use warnings;
use Parallel::ForkManager;

sub prtHelp{
    print "\nThis program is for constructing haplotype blocks for both parents with samtools. Please add the paths of samtools and bcftools to the environment variable of PATH.\n";
    print "\n";
    print "Usage: haplotyping.pl [Options] <parent1.bam> <parent2.bam>\n";
    print "\n";
    print "Options:\n";
    print "       -f <str> reference sequence file\n";
    print "       -Q <int> minimum base quality used in samtools phasing [20]\n";
    print "       -n <int> minimum number of snps in each haplotype block [5]\n";
    print "       -P <int> minimum number of reads supporting each allele in phasing [3]\n";
    print "       -A <int> minimum depth for each allele in heterozygous genotype [3]\n";
    print "       -G <int> minimum genotype quality for heterozygous genotype [30]\n";
    print "       -D1 <int> minimum depth for heterozygous genotype [6]\n";
    print "       -D2 <int> minimum depth for homozygous genotype [5]\n";
    print "       -m1 <str> linkage map file of parent 1\n";
    print "       -m2 <str> linkage map file of parent 2\n";
    print "\n";
} 

if(@ARGV<2){
	prtHelp();
     	die "No input files provided\n";
}

use Getopt::Long;

my $i;
my($Q,$num,$prefix1,$prefix2,$phase_reads,$dp,$a,$gq,$dp2);
my ($refseqfile,$map1file,$map2file);

GetOptions(
    	"f:s"=>\$refseqfile,
    	"Q:i"=>\$Q,
	"n:i"=>\$num,
     	"P:i"=>\$phase_reads,
     	"A:i"=>\$a,
     	"G:i"=>\$gq,
     	"D1:i"=>\$dp,
     	"D2:i"=>\$dp2,
	"m1:s"=>\$map1file,
	"m2:s"=>\$map2file
);

$ARGV[0] =~ /(.*)\_rmdup.bam/;
unless($1){ 
	die "Error: The bam file of parent 1 does not exist\!\n"; 
}
$prefix1 = $1;
$ARGV[1] =~ /(.*)_rmdup.bam/;
unless($1){ 
	die "Error: The bam file of parent 2 does not exist\!\n"; 
}
$prefix2 = $1;

unless($Q){ $Q=20;}
unless($num){ $num=5;}
unless($phase_reads){ $phase_reads=3;}
unless($a){ $a=3;}
unless($gq){ $gq=30;}
unless($dp){ $dp=6;}
unless($dp2){ $dp2=5;}
unless($refseqfile){
	die "Error: Please provide the reference file\!\n";
}

system("samtools phase -Q $Q -A -b $ARGV[0] > $prefix1.phase");
system("samtools phase -Q $Q -A -b $ARGV[1] > $prefix2.phase");

system("awk '\$1\!~/CC|FL|M2|EV/' $prefix1.phase > $prefix1.bl");
system("awk '\$1\!~/CC|FL|M2|EV/' $prefix2.phase > $prefix2.bl");

open(IN1,"<$prefix1.bl");
open(IN2,"<$prefix2.bl");
local $/=undef;

my ($str1,$str2);
my ($n1,$n2);
$str1 = <IN1>;
$str2 = <IN2>;
close IN1;
close IN2;

my (@block1,@block2,@line);

open(OUT1,">$prefix1.bl2");
open(OUT2,">$prefix2.bl2");

@block1 = split/\n\/\/\n/,$str1;
foreach (@block1){
      chomp $_;
      @line = split/\n/,$_;
      $n1 = scalar @line;
      if($n1 > $num){
		print OUT1 "$_\n\/\/\n";
	}
}

@block2 = split/\n\/\/\n/,$str2;
foreach (@block2){
      chomp $_;
      @line = split/\n/,$_;
      $n2 = scalar @line;
      if($n2 > $num){
		print OUT2 "$_\n\/\/\n";
	}
}

close OUT1;
close OUT2;

my $cmd;

$cmd = "awk '{if(\$1~/PS|\\\/\\\//){print \$0} else if(\$1~/M1/){print \$1,\$2,\$4,\$5,\$6}}' OFS=\"\\t\" $prefix1.bl2 > $prefix1.haplotype";
system($cmd);
$cmd = "awk '{if(\$1~/PS|\\\/\\\//){print \$0} else if(\$1~/M1/){print \$1,\$2,\$4,\$5,\$6}}' OFS=\"\\t\" $prefix2.bl2 > $prefix2.haplotype";
system($cmd);

$cmd = "awk '{if(\$1~/M1/){print \$2,\$3}}' OFS=\"\t\" $prefix1.haplotype > $prefix1.hap.loc";
system($cmd);
$cmd = "awk '{if(\$1~/M1/){print \$2,\$3}}' OFS=\"\t\" $prefix2.haplotype > $prefix2.hap.loc";
system($cmd);

my ($pm,$pid,@bamprx);
@bamprx = ($prefix1,$prefix2);
$pm = new Parallel::ForkManager(2);
for($i=0;$i<2;$i++){
	$pid = $pm->start and next;
	$cmd = "samtools mpileup -g -Q $Q -t DPR -f $refseqfile $bamprx[$i]\_rmdup.bam > $bamprx[$i].bcf";
	system($cmd);
	$pm->finish;
}
$pm->wait_all_children;

my @bcfcmds;
$bcfcmds[0] = "bcftools call -m -V indels -f GQ -T $prefix1.hap.loc $prefix1.bcf > $prefix1.hap.loc\_p1.vcf";
$bcfcmds[1] = "bcftools call -m -V indels -f GQ -T $prefix1.hap.loc $prefix2.bcf > $prefix1.hap.loc\_p2.vcf";
$bcfcmds[2] = "bcftools call -m -V indels -f GQ -T $prefix2.hap.loc $prefix1.bcf > $prefix2.hap.loc\_p1.vcf";
$bcfcmds[3] = "bcftools call -m -V indels -f GQ -T $prefix2.hap.loc $prefix2.bcf > $prefix2.hap.loc\_p2.vcf";

$pm = new Parallel::ForkManager(4);
for($i=0;$i<4;$i++){
	$pid = $pm->start and next;
	system($bcfcmds[$i]);
	$pm->finish;
}
$pm->wait_all_children;

$cmd = "perl extractvcf.pl $prefix1.hap.loc_p1.vcf $prefix1.haplotype > $prefix1.block.stat";
system($cmd);
$cmd = "perl extracthomogt.pl $prefix1.hap.loc_p2.vcf $prefix1.block.stat > abxaa.block.stat";
system($cmd);

$cmd = "perl extractvcf.pl $prefix2.hap.loc_p2.vcf $prefix2.haplotype > $prefix2.block.stat";
system($cmd);
$cmd = "perl extracthomogt.pl $prefix2.hap.loc_p1.vcf $prefix2.block.stat > aaxab.block.stat";
system($cmd);

$cmd = "awk '\$0\!~/*/' abxaa.block.stat | awk '{if(\$1~/PS|\\/\\//){print \$0} else if(\$6>=$a && \$7>=$a && \$9>$gq){print \$0}}' > abxaa.blocks";
system($cmd);
$cmd = "awk '\$0\!~/*/' aaxab.block.stat | awk '{if(\$1~/PS|\\/\\//){print \$0} else if(\$6>=$a && \$7>=$a && \$9>$gq){print \$0}}' > aaxab.blocks";
system($cmd);

$cmd = "perl blocknumfilter.pl -L $num abxaa.blocks > abxaa.blocks_filtered";
system($cmd);
$cmd = "perl blocknumfilter.pl -L $num aaxab.blocks > aaxab.blocks_filtered";
system($cmd);

$cmd = "perl allelsformat.pl abxaa.blocks_filtered > $prefix1.abxaa.blocks";
system($cmd);
$cmd = "perl allelsformat.pl aaxab.blocks_filtered > $prefix2.aaxab.blocks";
system($cmd);

$cmd = "awk '{if(\$1~/\\/\\//){print \$0} else print \$1,\$2,\$3,\$5,\$4}' OFS=\"\\t\" $prefix1.abxaa.blocks > $prefix1.abxaa.rev.blocks";
system($cmd);
$cmd = "awk '{if(\$1~/\\/\\//){print \$0} else print \$1,\$2,\$3,\$5,\$4}' OFS=\"\\t\" $prefix2.aaxab.blocks > $prefix2.aaxab.rev.blocks";
system($cmd);

if( $map1file && $map2file){
	if( -e $map1file && -e $map2file){
		$cmd = "perl longhapcall.pl $prefix1.abxaa.blocks $prefix1.abxaa.rev.blocks $map1file $prefix1.long.haplotype";
		system($cmd);
		$cmd = "perl longhapcall.pl $prefix2.aaxab.blocks $prefix2.aaxab.rev.blocks $map2file $prefix2.long.haplotype";
		system($cmd);

		$cmd = "awk '{print \$1,\$2}' OFS=\"\t\" $prefix1.long.haplotype > $prefix1.longhap.loc";
		system($cmd);
		$cmd = "awk '{print \$1,\$2}' OFS=\"\t\" $prefix2.long.haplotype > $prefix2.longhap.loc";
		system($cmd);
	}else{
		print "The linkage map files do  not exist\!\n";
	}
}else{
	print "The linkage map files are not provided or do not exist\!\n";
}

$cmd = "perl blocknumfilter.pl -L 5 $prefix1.abxaa.blocks > $prefix1.abxaa.5snps.blocks";
system($cmd);
$cmd = "perl blocknumfilter.pl -L 5 $prefix2.aaxab.blocks > $prefix2.aaxab.5snps.blocks";
system($cmd);

$cmd = "awk '{if(\$1~/M/){print \$2,\$3}}' OFS=\"\t\" $prefix1.abxaa.5snps.blocks > $prefix1.abxaa.5snps.blocks.loc";
system($cmd);
$cmd = "awk '{if(\$1~/M/){print \$2,\$3}}' OFS=\"\t\" $prefix2.aaxab.5snps.blocks > $prefix2.aaxab.5snps.blocks.loc";
system($cmd);


exit;
